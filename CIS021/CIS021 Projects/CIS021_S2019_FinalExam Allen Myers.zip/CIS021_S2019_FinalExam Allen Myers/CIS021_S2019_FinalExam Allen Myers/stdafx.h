// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>



// TODO: reference additional headers your program requires here
#include <iostream>										// i/o
#include<iomanip>										//formatting
#include<string>										//string library
#include<random>										//random number gen

#define LIST_SIZE 1000000								//size of 1 million

using namespace std;

